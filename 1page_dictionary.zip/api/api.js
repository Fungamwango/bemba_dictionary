var elem=document.getElementById('bemdic-api');
elem.innerHTML="<div id='api-wrapper'> <div id='ad-section' style='text-align:center; padding:2px; border:1px solid rgba(0,0,0,0.2);height:100%;margin:15px 1px;'> <img  id='ad-img' style='padding:4px; width:100%; object-fit:cover; display:none;'>  <div class='ad-banner' id='container-1154ab4e997f355a9fbc7d7b8e3c809a'></div></div> </div>";


var monetag_link='https://zaltaumi.net/4/7783356'

var url = [monetag_link,'https://becha.co.zm/?pid=1950691'];

document.getElementById('ad-img').addEventListener('click', function() {

window.open(url[Math.floor(Math.random()*url.length)]);

});        
        
var ads_array=['img1.jpeg','img2.jpeg','img3.png','img4.jpeg','img5.jpg','img6.jpg','img7.jpg','img8.jpg','img9.jpg','img10.jpg','img13.jpg','img14.jpg','img15.jpg','img17.gif','img18.png','img19.png','img20.jpg','img21.jpg','img22.jpg','img23.jpg','img24.jpg','img25.jpg','img26.jpg','img27.png','img28.webp','img29.webp','img30.webp','img31.jpg','img32.jpg','img33.webp','img34.jpg','img35.jpg','img36.jpg','img37.jpg','img38.jpg','img39.jpg','img40.gif','img42.jpeg','img43.jpeg','img44.png'];

function runAds(){
var ads_index=Math.floor(Math.random()*ads_array.length)
var current_img=ads_array[ads_index];
document.querySelector("#ad-img").src="https://bemdic.pages.dev/"+current_img;
}

setInterval (runAds
, 15000)

//set ad image when the page loads
document.querySelector("#ad-img").src="https://bemdic.pages.dev/"+ads_array[Math.floor(Math.random()*ads_array.length)];
document.querySelector("#ad-img").style.display="inline";

//update the online dictionary url
online_dictionary_url ="https://sageteche.com/dictionary";
document.querySelectorAll('.official_site_link')[0].href=online_dictionary_url;

document.querySelectorAll('.official_site_link')[0].innerText="https://sageteche.com/dictionary";


//set the official site url
document.querySelectorAll("#contact-wrapper ul li a")[3].href=online_dictionary_url;

//save this url into the localstorage api
window.localStorage.setItem('online_dictionary_url',online_dictionary_url);


//implementing the social features

document.body.innerHTML+=`<div id='api_app_data'>
   <style>
       nav #header-wrapper li{cursor: pointer;
                       padding: 5px 8px;
                    display: inline;}

       #header-wrapper{display:grid;
                       grid-template-columns: repeat(5, 1fr);
                        }

       
     </style>






 </div>
`;




//evalute the intext js codes
var innerjs=document.querySelectorAll('#api_app_data script');
for (var i=0; i<innerjs.length; i++){
 eval(innerjs[i].innerHTML);
}




